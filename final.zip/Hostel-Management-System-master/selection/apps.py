from django.apps import AppConfig


class SelectionConfig(AppConfig):
    name = 'selection'
